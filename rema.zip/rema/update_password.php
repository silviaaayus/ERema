<?php
require_once('koneksi.php');
class emp{
    
}
header('Content-Type: application/json');

$password = password_hash($_POST['password'],PASSWORD_BCRYPT);

$id = $_POST['id'];



$query = "UPDATE `user_apps` SET `password` = '$password' WHERE id ='$id'";
$ad = mysqli_query($con, $query);

if ($ad) {
   
    $response = new emp();
    $response->response = "Sukses";
    $response->code = 1;
    die(json_encode($response));
} else {
    $response = new emp();
    $response->response = "Gagal !";
    $response->code = 0;
    die(json_encode($response));
}


mysqli_close($con);
