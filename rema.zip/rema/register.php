<?php
require_once('koneksi.php');
header('Content-Type: application/json');
class emp
{
}

$password = password_hash($_POST['password'],PASSWORD_BCRYPT);
$nama= $_POST['nama'];
$tgl_lahir = $_POST['tgl_lahir'];
$alamat = $_POST['alamat'];
$email = $_POST['email'];
$jekel = $_POST['jekel'];
$foto_profil = $_POST['foto_profil'];

$random = random_word(20);
$path = $random . ".png";





$hm = "SELECT * FROM `user_apps` where `email`='$email'";
$ad = mysqli_query($con, $hm);
$cek = mysqli_affected_rows($con);

if($cek > 0){
    $res = new emp();
    $res->message = "Email sudah ada. Silahkan Login Menggunakan Akun Google";
    $res->status = "ada";
    die(json_encode($res));
   

}else{
    $query = "INSERT INTO user_apps(email,password,nama,tgl_lahir,alamat,jekel,foto_profil) 
VALUES('$email','$password','$nama','$tgl_lahir','$alamat','$jekel','$path')";

$ad = mysqli_query($con, $query);
 
if ($ad) {
    file_put_contents("imgprofil/" . $random . ".png", base64_decode($foto_profil));
    $res = new emp();
    $res->message = "Sukses Input";
    $res->status = "sukses";
    die(json_encode($res));
} else {
    $res = new emp();
    $res->message = "Gagal Input";
    $res->status = "gagal";
    die(json_encode($res));
    }
}
function random_word($id = 20)
{
    $pool = '1234567890abcdefghijkmnpqrstuvwxyz';

    $word = '';
    for ($i = 0; $i < $id; $i++) {
        $word .= substr($pool, mt_rand(0, strlen($pool) - 1), 1);
    }
    return $word;
}






mysqli_close($con);
?>
