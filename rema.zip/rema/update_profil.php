<?php
require_once('koneksi.php');
class emp{
    
}
header('Content-Type: application/json');

$nama = $_POST['nama'];
$tgl_lahir = $_POST['tgl_lahir'];
$id = $_POST['id'];
$alamat = $_POST['alamat'];
$email = $_POST['email'];
$jekel = $_POST['jekel'];
$foto_profil = $_POST['foto_profil'];

$random = random_word(20);
$path = $random . ".png";



$query = "UPDATE `user_apps` 
SET `nama` = '$nama', 
`tgl_lahir` = '$tgl_lahir',
`alamat` = '$alamat',
`email` = '$email',
`jekel` = '$jekel',
`foto_profil` = '$path'

WHERE id ='$id'";
$ad = mysqli_query($con, $query);

if ($ad) {
    file_put_contents("imgprofil/" . $random . ".png", base64_decode($foto_profil));
    $response = new emp();
    $response->response = "Sukses";
    $response->code = 1;
    die(json_encode($response));
} else {
    $response = new emp();
    $response->response = "Gagal !";
    $response->code = 0;
    die(json_encode($response));
}

function random_word($id = 20)
{
    $pool = '1234567890abcdefghijkmnpqrstuvwxyz';

    $word = '';
    for ($i = 0; $i < $id; $i++) {
        $word .= substr($pool, mt_rand(0, strlen($pool) - 1), 1);
    }
    return $word;
}


mysqli_close($con);
