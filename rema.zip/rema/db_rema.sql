-- phpMyAdmin SQL Dump
-- version 4.2.7.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Feb 14, 2022 at 09:36 AM
-- Server version: 5.6.20
-- PHP Version: 5.5.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `db_rema`
--

-- --------------------------------------------------------

--
-- Table structure for table `beritas`
--

CREATE TABLE IF NOT EXISTS `beritas` (
`id` int(11) NOT NULL,
  `judul` varchar(255) NOT NULL,
  `isi` text NOT NULL,
  `user_id_penulis` varchar(255) NOT NULL,
  `waktu_rilis` date NOT NULL,
  `kategori` varchar(255) NOT NULL,
  `thumbnail` varchar(255) NOT NULL,
  `penulis` varchar(255) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `beritas`
--

INSERT INTO `beritas` (`id`, `judul`, `isi`, `user_id_penulis`, `waktu_rilis`, `kategori`, `thumbnail`, `penulis`) VALUES
(1, 'TESTING BERITA', 'KOSONG', '1', '2022-01-13', 'today', 'calendar.png', 'Budi'),
(2, 'TESTING BERITA 1', 'KOSONG', '1', '2022-01-13', 'today', 'calendar.png', 'Budi');

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE IF NOT EXISTS `events` (
`id_event` int(11) NOT NULL,
  `nama_event` varchar(225) NOT NULL,
  `tanggal_event` date NOT NULL,
  `lokasi_event` varchar(225) NOT NULL,
  `jam_mulai` varchar(225) NOT NULL,
  `ket` text NOT NULL,
  `status` varchar(225) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`id_event`, `nama_event`, `tanggal_event`, `lokasi_event`, `jam_mulai`, `ket`, `status`) VALUES
(1, 'as', '2022-01-27', 'asaa', '10', 'fwe', 'Aktif'),
(2, 'asdsfad', '2022-01-15', 'asaaaf', '10', 'fwesadaf', 'Aktif'),
(3, 'asdsfadsdasfd', '2022-03-04', 'asaaafswdef', '10', 'fwesadafsdasfd', 'Aktif'),
(4, 'asdsfadsdasfd', '2022-02-23', 'asaaafswdef', '10', 'fwesadafsdasfd', 'Aktif'),
(5, 'asdsfadsdasfdscdfv', '2022-02-23', 'asaaafswdef', '10', 'fwesadafsdasfd', 'Aktif');

-- --------------------------------------------------------

--
-- Table structure for table `fiturs`
--

CREATE TABLE IF NOT EXISTS `fiturs` (
`id` int(11) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `gambar` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `fiturs`
--

INSERT INTO `fiturs` (`id`, `nama`, `gambar`, `created_at`, `updated_at`) VALUES
(1, 'Upi Event', 'calendar.png', '2022-01-10 13:41:19', '0000-00-00 00:00:00'),
(2, 'Upi Today', 'newspaper.png', '2022-01-10 13:41:19', '0000-00-00 00:00:00'),
(3, 'Upi Maps', 'map.png', '2022-01-10 13:41:19', '0000-00-00 00:00:00'),
(4, 'Upi Beasiswa', 'scholarship.png', '2022-01-10 13:41:19', '0000-00-00 00:00:00'),
(5, 'Upi Volunteer', 'volunteer.png', '2022-01-10 13:41:19', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `user_apps`
--

CREATE TABLE IF NOT EXISTS `user_apps` (
`id` int(11) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `jekel` varchar(255) NOT NULL,
  `tgl_lahir` date NOT NULL,
  `alamat` text NOT NULL,
  `email` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `foto_profil` varchar(255) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `user_apps`
--

INSERT INTO `user_apps` (`id`, `nama`, `jekel`, `tgl_lahir`, `alamat`, `email`, `username`, `password`, `foto_profil`) VALUES
(4, 'Silvia Ayu Santika', 'P', '1997-04-09', 'Padang', 'silviaayu0904@gmail.com', 'silvia', '$2y$10$BkEo6.yw8Nnd4UFSDgPJKuPv9yntME9RNQJD0h0GTZJP9ansnVXyG', ''),
(5, 'as', 'L', '2022-01-18', 'sa', 'as', 'sa', 'as', ''),
(7, 'Mahasiswa', 'P', '1999-01-25', 'padang', 'mahasiswa@gmail.com', 'mahasiswa', '$2y$10$pK6T0e7FmZIvHat.j1.Iqev4ZbbiY3ukoHBuSYIlLF1NXowZzbzvu', ''),
(8, 'Silvia Ayu Santikaa', 'P', '1990-10-10', 'padang', '', 'budi', '$2y$10$OvTgvSvzQGmmPPQPU0lCE.UEcEtKePDbcJYiVA1twJegRV3i0w2Zi', 'tzxqiwv18m54h4f44ryx.png'),
(9, 'Silvia Ayu Santikaa', 'P', '1990-10-10', 'padang', 'a', 'budi', '$2y$10$nWXleQDim9vg6wr296lxxuyWbnhcvW22PaIWKc448cXu3bFfg2KzS', 'cymfacae4bhri7svnn8n.png'),
(10, 'Silvia Ayu Santikaa', 'P', '1990-10-10', 'padang', 'a', 'q', '$2y$10$SMjl04OPPI6HZ/4QMBKHMen5dJw9mXgxKi8tw5zhmwb1Kd1eCtOyW', 'tfmnczjh361gnaqiydxx.png');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `beritas`
--
ALTER TABLE `beritas`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
 ADD PRIMARY KEY (`id_event`);

--
-- Indexes for table `fiturs`
--
ALTER TABLE `fiturs`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_apps`
--
ALTER TABLE `user_apps`
 ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `beritas`
--
ALTER TABLE `beritas`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
MODIFY `id_event` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `fiturs`
--
ALTER TABLE `fiturs`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `user_apps`
--
ALTER TABLE `user_apps`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=11;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
