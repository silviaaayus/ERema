<?php
require_once('koneksi.php');
header('Content-Type: application/json');


$perintah = "SELECT tanggal_event, DAY(tanggal_event) as day, MONTH(tanggal_event) as month, YEAR(tanggal_event) as year 
FROM events WHERE status='Aktif' GROUP BY tanggal_event ORDER BY tanggal_event ASC";

$eksekusi = mysqli_query($con, $perintah);
$cek = mysqli_affected_rows($con);

if ($cek > 0) {
    $response["status"] = 'sukses';
    $response["pesan"] = "Data tersedia";
    $response["res"] = array();
    $F = array();
    while ($ambil = mysqli_fetch_object($eksekusi)) {
        $F[] = $ambil;
    }
    $response["res"] = $F;
} else {
    $response["status"] = 'Gagal';
    $response["pesan"] = "Data Tak tersedia";
}
echo json_encode($response);
mysqli_close($con);
