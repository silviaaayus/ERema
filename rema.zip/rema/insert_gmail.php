<?php
require_once('koneksi.php');
header('Content-Type: application/json');
class emp
{
}

$nama_mhs = $_POST['nama'];
$jekel_mhs = $_POST['jekel'];
$tgl_lahir= $_POST['tgl_lahir'];
$alamat_mhs = $_POST['alamat'];
$email_mhs = $_POST['email'];



$hm = "SELECT * FROM `user_apps` where `email`='$email_mhs'";
$ad = mysqli_query($con, $hm);
$cek = mysqli_affected_rows($con);

if($cek > 0){
    $res = new emp();
    $res->message = "Data sudah ada";
    $res->status = "ada";
    die(json_encode($res));
}else{
            $query = "INSERT INTO user_apps(nama,jekel,tgl_lahir,alamat,email) 
        VALUES('$nama_mhs','$jekel_mhs','$tgl_lahir','$alamat_mhs','$email_mhs')";

        $ad = mysqli_query($con, $query);
    
        if ($ad) {
            $res = new emp();
            $res->message = "Sukses Input";
            $res->status = "sukses";
            die(json_encode($res));
        } else {
            $res = new emp();
            $res->message = "Gagal Input";
            $res->status = "gagal";
            die(json_encode($res));
        }

    }
mysqli_close($con);
?>
